## List broken VSCode Extension

### Optional for python

* ms-pyright.pyright
* ms-python.python
* ms-toolsai.jupyter
* ms-toolsai.jupyter-keymap
* ms-toolsai.jupyter-renderers
* ms-toolsai.vscode-jupyter-cell-tags
* ms-toolsai.vscode-jupyter-slideshow

### Nonfree

* ms-python.vscode-pylance

### Not running

* kamadorueda.alejandra
